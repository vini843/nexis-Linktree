# Nexis System | Links (nexislink.com.br)

Todos os arquivos ficam juntos na raiz, sem pastas:

index.html · style.css · main.js · favicon.svg · og-image.png

Na Hostinger, envie os 5 arquivos para dentro de `public_html` (substituindo os antigos).
